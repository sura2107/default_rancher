# Add Logspout Stack

Glider Labs Logspout with Logstash adapter

### Info:

For any services launched from the Rancher UI to use Logspout, please make sure to disable the '-t' [tty] option in the Advanced Options of the service definition. 
 