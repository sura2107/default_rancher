# MongoDB


### Info:

 This template creates MongoDB replica set on top of Rancher. Replica set size starts with 3 MongoDB instances, the replica set has the ability to scale up automatically when adding new instances. 
 
 
### Usage:

 Select MongoDB from catalog. 
 
 Enter the name of the replica set.
 
 Click deploy.
 
 MongoDB can now be accessed over the Rancher network. 
 
