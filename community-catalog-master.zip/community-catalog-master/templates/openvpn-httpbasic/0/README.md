# OpenVPN

OpenVPN stack made to give access to Rancher network with HTTP Basic authentication.

OpenVPN version: 1.0-0