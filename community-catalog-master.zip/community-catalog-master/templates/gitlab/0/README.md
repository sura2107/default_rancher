# GitLab CE

GitLab CE is a free alternative to GitHub

Stack based on official GitLab version: 8.5.1-ce.0

https://hub.docker.com/r/gitlab/gitlab-ce/


