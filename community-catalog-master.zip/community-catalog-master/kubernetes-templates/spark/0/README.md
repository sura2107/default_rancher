# spark

Apache Spark is a fast and general-purpose cluster computing system.

Need for zeppelin service and controller: Apache Zeppelin is a new and incubating multi-purposed web-based notebook which brings data ingestion, data exploration, visualization, sharing and collaboration features to Spark. More information can be found at https://zeppelin.incubator.apache.org/
